document.addEventListener('DOMContentLoaded', () => {
    const glow = document.getElementById('cursor-glow');
    const blob = document.getElementById('glow-blob');

    // Performance Optimization: Use requestAnimationFrame for all visual updates
    let mouseX = 0, mouseY = 0;
    let blobX = 0, blobY = 0;
    let isTicking = false;

    // Cache DOM elements to avoid querySelectorAll on every frame
    const spotlightCards = document.querySelectorAll('.spotlight-card, .glass-panel, .ctr-card');

    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;

        if (!isTicking) {
            window.requestAnimationFrame(() => {
                updateVisuals();
                isTicking = false;
            });
            isTicking = true;
        }
    });

    function updateVisuals() {
        // 1. Show Glow
        if (glow && glow.classList.contains('opacity-0')) {
            glow.classList.remove('opacity-0');
        }

        // 2. Update Spotlight Cards (Only if visible)
        spotlightCards.forEach(card => {
            // Simple optimization: check if card is roughly in viewport/near mouse
            // For now, just update CSS vars as it's lighter than bounding rects if done in rAF
            const rect = card.getBoundingClientRect();
            const x = mouseX - rect.left;
            const y = mouseY - rect.top;
            card.style.setProperty('--mouse-x', `${x}px`);
            card.style.setProperty('--mouse-y', `${y}px`);
        });

        // 3. Smooth Blob Follow
        if (blob) {
            blobX += (mouseX - blobX) * 0.1; // Increased speed for responsiveness
            blobY += (mouseY - blobY) * 0.1;
            blob.style.transform = `translate(${blobX}px, ${blobY}px)`;
        }
    }

    // Loop for smooth blob animation (separate from mousemove to keep momentum)
    function loop() {
        if (blob) {
            blobX += (mouseX - blobX) * 0.1;
            blobY += (mouseY - blobY) * 0.1;
            blob.style.transform = `translate(${blobX}px, ${blobY}px)`;
            requestAnimationFrame(loop);
        }
    }
    loop();

    // 4. Magnetic Buttons (Lightweight)
    const buttons = document.querySelectorAll('.btn-neon, .ctr-btn, a.button');
    buttons.forEach(btn => {
        btn.addEventListener('mousemove', (e) => {
            const rect = btn.getBoundingClientRect();
            const x = e.clientX - rect.left - rect.width / 2;
            const y = e.clientY - rect.top - rect.height / 2;
            btn.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px)`;
        });

        btn.addEventListener('mouseleave', () => {
            btn.style.transform = 'translate(0, 0)';
        });
    });
});
