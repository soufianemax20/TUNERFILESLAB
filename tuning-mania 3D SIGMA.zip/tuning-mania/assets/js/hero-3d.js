/**
 * TUNER FILES LAB - 3D ECU MAP VISUALIZATION
 * Uses Three.js to render an interactive wireframe mesh representing an ECU map.
 */

document.addEventListener('DOMContentLoaded', function () {
    console.log("3D Hero: Init");

    // Handle Loader
    const loader = document.getElementById('hero-loader');
    if (loader) {
        setTimeout(() => {
            loader.style.opacity = '0';
            setTimeout(() => { loader.style.display = 'none'; }, 1000);
        }, 800); // Short delay for effect
    }

    const container = document.getElementById('canvas-container');
    if (!container) {
        console.warn("3D Hero: No Container");
        return;
    }

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x050505, 0.002);

    const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 1000);
    camera.position.set(0, 50, 100);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // --- ECU MAP SURFACE ---
    const geometry = new THREE.PlaneGeometry(120, 120, 50, 50);

    // Material: Stock Blue initially
    const material = new THREE.MeshBasicMaterial({
        color: 0x22aaff,
        wireframe: true,
        transparent: true,
        opacity: 1.0,
        side: THREE.DoubleSide
    });

    const plane = new THREE.Mesh(geometry, material);
    plane.rotation.x = -Math.PI / 2;
    scene.add(plane);

    // --- UNDER GLOW ---
    const glowGeo = new THREE.CircleGeometry(60, 32);
    const glowMat = new THREE.MeshBasicMaterial({
        color: 0x22aaff,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.15
    });
    const glow = new THREE.Mesh(glowGeo, glowMat);
    glow.rotation.x = -Math.PI / 2;
    glow.position.y = -5;
    scene.add(glow);

    // --- PARTICLES ---
    const particlesGeo = new THREE.BufferGeometry();
    const count = 400;
    const positions = new Float32Array(count * 3);

    for (let i = 0; i < count * 3; i += 3) {
        positions[i] = (Math.random() - 0.5) * 120; // x
        positions[i + 1] = Math.random() * 60 - 20;   // y
        positions[i + 2] = (Math.random() - 0.5) * 120; // z
    }

    particlesGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const particlesMat = new THREE.PointsMaterial({
        color: 0x22aaff,
        size: 0.8,
        transparent: true,
        opacity: 0.6
    });
    const particleSystem = new THREE.Points(particlesGeo, particlesMat);
    scene.add(particleSystem);

    // --- SCENE LIGHTING (No Car) ---
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.3);
    scene.add(ambientLight);
    const dirLight = new THREE.DirectionalLight(0xD7F207, 1.5); // Neon accent light
    dirLight.position.set(10, 20, 10);
    scene.add(dirLight);

    // --- ANIMATION LOGIC ---
    const originalPositions = geometry.attributes.position.array.slice();
    let sliderValue = 0;

    // DOM Elements for Interaction
    const slider = document.getElementById('tuning-slider');
    const hpStat = document.getElementById('hp-stat');
    const nmStat = document.getElementById('nm-stat');

    // Base Stats
    const stockHP = 180; const targetHP = 265;
    const stockNM = 320; const targetNM = 440;

    if (slider) {
        slider.addEventListener('input', (e) => {
            sliderValue = parseInt(e.target.value);
            updateSim(sliderValue);
        });

        // Trigger initial state
        updateSim(0);
    }

    function updateSim(val) {
        const fraction = val / 100;

        // Color Interpolation
        const colorStock = new THREE.Color(0x22aaff);
        const colorTuned = new THREE.Color(0xD7F207);
        const currentColor = colorStock.clone().lerp(colorTuned, fraction);

        material.color = currentColor;
        glowMat.color = currentColor;
        particlesMat.color = currentColor;
        particlesMat.size = 0.8 + (fraction * 0.5);

        // Update Text
        if (hpStat) {
            const currentHP = Math.floor(stockHP + (targetHP - stockHP) * fraction);
            hpStat.innerHTML = `${currentHP} <span>hp</span>`;
        }
        if (nmStat) {
            const currentNM = Math.floor(stockNM + (targetNM - stockNM) * fraction);
            nmStat.innerHTML = `${currentNM} <span>Nm</span>`;
        }
    }

    // --- LOOP ---
    let time = 0;
    function animate() {
        requestAnimationFrame(animate);
        time += 0.05;

        // Rotation
        scene.rotation.y = time * 0.002;

        // Wave Animation
        const positionAttribute = geometry.attributes.position;
        const vertexCount = positionAttribute.count;
        const tuneFactor = sliderValue / 100;

        // "Rolling Road" Speed
        const speed = time * (2 + tuneFactor * 3); // Faster when tuned

        for (let i = 0; i < vertexCount; i++) {
            // Original flat coordinates
            const x = originalPositions[i * 3];
            const y = originalPositions[i * 3 + 1]; // Z in local space (Y in plane geo before rotation)

            // Wave calc - OFFSET Y by Speed to create scrolling effect
            const effectiveY = y - speed * 5;

            const waveHeight = (Math.sin(x / 6 + time + tuneFactor * 5) + Math.cos(effectiveY / 10)) * 2;
            const boostLift = tuneFactor * 12;
            const aggressiveMult = 0.2 + (tuneFactor * 4.0);

            // Dist from center for shaping
            const dist = Math.sqrt(x * x + y * y);
            const shapeMod = Math.max(0, (60 - dist) / 60); // Fade edges

            // Apply to Z (Height)
            positionAttribute.setZ(i, (waveHeight * aggressiveMult * shapeMod) + (boostLift * shapeMod));
        }
        positionAttribute.needsUpdate = true;

        // Particles - Flow Past Camera
        const pPositions = particlesGeo.attributes.position.array;
        const speedMultiplier = 1 + (tuneFactor * 3);

        for (let i = 1; i < count * 3; i += 3) {
            // Move particles towards camera (positive Z? No, check coord system)
            // Camera at Z=100. Particles random. Let's maintain visual flow.
            pPositions[i + 1] += 0.5 * speedMultiplier; // Move 'forward' relative to car
            if (pPositions[i + 1] > 50) pPositions[i + 1] = -50; // Wrap around
        }
        particlesGeo.attributes.position.needsUpdate = true;

        renderer.render(scene, camera);
    }

    animate();

    // --- RESIZE ---
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });

    // --- MOUSE PARALLAX ---
    document.addEventListener('mousemove', (e) => {
        const mouseX = (e.clientX - window.innerWidth / 2) * 0.02;
        const mouseY = (e.clientY - window.innerHeight / 2) * 0.02;

        gsap.to(camera.position, {
            duration: 1,
            x: mouseX,
            y: 50 + mouseY * 0.5,
            ease: "power2.out"
        });
    });

    // --- INTRO ANIMATION ---
    // Auto-move slider once to show user functionality
    if (slider) {
        setTimeout(() => {
            gsap.to(slider, {
                value: 40,
                duration: 2,
                ease: "power2.inOut",
                yoyo: true,
                repeat: 1,
                onUpdate: () => {
                    updateSim(slider.value); // Manually trigger update
                }
            });
        }, 1500);
    }
});