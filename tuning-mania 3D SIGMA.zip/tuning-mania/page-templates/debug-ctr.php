<?php
/**
 * Template Name: Debug CTR Plugin
 *
 * Diagnostic tool to inspect ChiptuningReseller plugin data and structure.
 * USE ONLY FOR DEBUGGING.
 *
 * @package Tuning_Mania
 */

get_header(); ?>

<main id="primary" class="site-main container mx-auto px-4 py-12 text-white bg-black min-h-screen">
    <h1 class="text-3xl font-bold text-neon-yellow mb-8">CTR Plugin Diagnostic</h1>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        <!-- BLOCK 1: Database Tables -->
        <div class="bg-gray-900 p-6 rounded-xl border border-gray-800">
            <h2 class="text-xl font-bold text-white mb-4 border-b border-gray-700 pb-2">Database Tables</h2>
            <pre class="bg-black p-4 rounded text-xs text-green-400 overflow-auto h-64">
<?php
global $wpdb;
$tables = $wpdb->get_results( "SHOW TABLES LIKE '%ctr%'" );
if ( $tables ) {
    foreach ( $tables as $table ) {
        $table_name = current( $table );
        echo $table_name . "\n";
        
        // Count rows
        $count = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name" );
        echo "  - Rows: " . $count . "\n";
        
        // Show columns for key tables
        if ( strpos($table_name, 'brands') !== false || strpos($table_name, 'types') !== false ) {
             $cols = $wpdb->get_results( "DESCRIBE $table_name" );
             echo "  - Columns: ";
             foreach($cols as $col) echo $col->Field . " ";
             echo "\n";
        }
        echo "\n";
    }
} else {
    echo "No tables found matching '%ctr%'. Plugin might not be installed or uses different prefix.";
}
?>
            </pre>
        </div>

        <!-- BLOCK 2: Vehicle Types Data -->
        <div class="bg-gray-900 p-6 rounded-xl border border-gray-800">
            <h2 class="text-xl font-bold text-white mb-4 border-b border-gray-700 pb-2">Vehicle Types (DB)</h2>
            <pre class="bg-black p-4 rounded text-xs text-yellow-400 overflow-auto h-64">
<?php
// Try to find the vehicle types table
$types_table = null;
if ($tables) {
    foreach($tables as $t) {
        $tn = current($t);
        if (strpos($tn, 'vehicle_types') !== false || strpos($tn, 'vehicletypes') !== false) {
            $types_table = $tn;
            break;
        }
    }
}

if ($types_table) {
    $types = $wpdb->get_results( "SELECT * FROM $types_table LIMIT 20" );
    print_r($types);
} else {
    echo "Could not identify a 'vehicle_types' table.\n";
    echo "Trying 'brands' table to see 'type' column...\n";
    
    // Check brands table for 'type' column
    $brands_table = null;
    foreach($tables as $t) {
        $tn = current($t);
        if (strpos($tn, 'brands') !== false) {
            $brands_table = $tn;
            break;
        }
    }
    
    if ($brands_table) {
        $sample_brand = $wpdb->get_row("SELECT * FROM $brands_table LIMIT 1");
        print_r($sample_brand);
    }
}
?>
            </pre>
        </div>

        <!-- BLOCK 3: Plugin Constants & Classes -->
        <div class="bg-gray-900 p-6 rounded-xl border border-gray-800">
            <h2 class="text-xl font-bold text-white mb-4 border-b border-gray-700 pb-2">Plugin Classes</h2>
            <pre class="bg-black p-4 rounded text-xs text-blue-400 overflow-auto h-64">
<?php
$classes = get_declared_classes();
$ctr_classes = array_filter($classes, function($c) {
    return stripos($c, 'ctr') !== false || stripos($c, 'chiptuning') !== false;
});
print_r(array_values($ctr_classes));
?>
            </pre>
        </div>

        <!-- BLOCK 4: Shortcode Output Test -->
        <div class="bg-gray-900 p-6 rounded-xl border border-gray-800">
            <h2 class="text-xl font-bold text-white mb-4 border-b border-gray-700 pb-2">Shortcode Test</h2>
            <div class="bg-white p-4 rounded text-black">
                <?php echo do_shortcode('[ctr_show_selector]'); ?>
            </div>
        </div>

    </div>
</main>

<?php get_footer(); ?>
