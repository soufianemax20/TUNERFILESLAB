<?php
// PHP Test File
echo "PHP is working correctly!";
echo "<br>Theme Path: " . get_template_directory();
?>
